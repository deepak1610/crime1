var fs=require('fs');
var lineReader = require('readline').createInterface({
 input: fs.createReadStream('ex.csv')
});

var arrest,typ,yr;
//var a,b;
var data;
var count=0;
function yeardata(yr,true1,false1)
{
 this.yr=yr;
 this.true1=true1;
 this.false1=false1;

}
var years=[];
var yearspdata=[];// final JSON object


lineReader.on('line', function (line)
{
count=count+1;
 if(count==1)
 {
   //console.log();
    var header=line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    //console.log(h);
for(var i=0;i<header.length;i++)
 {
   if(header[i]=="Arrest")
   {
     arrest=i;


   }
   if(header[i]=="Primary Type")
   {
     typ=i;
   }
   if(header[i]=="Year")
   {
     yr=i;
   }

}
}
 else if(count>=2)
 {
    data=line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);


if(data[typ]=="ASSAULT")
{
  var year=(data[yr]);

  var index=years.indexOf(year);
  if(index<0)
  {
   years.push(year);
   var yrdata=new yeardata(year,0,0);
   if(data[arrest]=="false")
   {
     yrdata.false1=yrdata.false1+1;
   }
   else if(data[arrest]=="true")
   {
     yrdata.true1=  yrdata.true1+1;
   }
   yearspdata.push(yrdata);

  }
  else
  {
  var yrdata=yearspdata[index];
  if(data[arrest]=="false")
  {
   yrdata.false1=yrdata.false1+1;
  }
  else if(data[arrest]=="true")
  {
   yrdata.true1=  yrdata.true1+1;
  }
  yearspdata[index]=yrdata;

  }

}


 }



//  console.log(yearspdata);
});

/*yearspdata.sort(function(a,b){
  return parseInt(a.yr)-parseInt(b.yr);
});
*/
lineReader.on('close', function() {


 yearspdata.sort(function(a,b){
   return parseInt(a.yr)-parseInt(b.yr);
 });
  console.log(yearspdata);
   var file=JSON.stringify(yearspdata);

   fs.writeFile("part_2_json.json",file,"utf8",function(error){
     if(error)
     throw error;
     });

});
